'''
        @author: CarolinaFernandez
        @organization: i2CAT, OFELIA FP7

        PolicyEngine Exceptions class
        Encapsulates custom exceptions 
'''

class ZeroPolicyObjectsReturned(Exception):
    pass

class MultiplePolicyObjectsReturned(Exception):
    pass
